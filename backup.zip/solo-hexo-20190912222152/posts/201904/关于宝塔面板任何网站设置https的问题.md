title: 关于宝塔面板任何网站设置https 的问题
date: '2019-04-14 15:24:36'
updated: '2019-04-14 15:24:36'
tags: [建站杂谈]
permalink: /articles/2019/04/14/1555226676012.html
---
第一步去你的服务器提供商那里申请一个ssl证书。

在宝塔面板修改nginx配置文件，在http的花括号里加上一行

add_header Content-Security-Policy upgrade-insecure-requests;  

不要换行，就在一行上，注意分号！

重载Nginx。

添加ssr证书。

强制https ，大功告成！

  

我第一次弄的时候没有修改Nginx，直接安装https证书和强制https，导致网页乱码，修改Nginx后，解决了这个问题。

感谢许心痕对我的帮助！