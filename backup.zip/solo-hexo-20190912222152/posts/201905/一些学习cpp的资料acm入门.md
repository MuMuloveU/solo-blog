title: 一些学习cpp的资料，acm入门。
date: '2019-05-13 17:08:28'
updated: '2019-05-15 10:53:58'
tags: [cpp, acm]
permalink: /articles/2019/05/13/1557738508344.html
---
如果你的cpp学的不扎实的话，建议先巩固一下基础，把这个网页的编程题过一遍。
https://www.runoob.com/cplusplus/cpp-examples.html
一些资料也可去这里查
https://www.runoob.com/cplusplus/cpp-tutorial.html
C++ 有用的网站
---------

*   [C++ Programming Language Tutorials](http://www.cs.wustl.edu/~schmidt/C++/) − C++ 编程语言教程。
*   [C++ Programming](http://en.wikibooks.org/wiki/C++_Programming) − 这本书涵盖了 C++ 语言编程、软件交互设计、C++ 语言的现实生活应用。
*   [C++ FAQ](http://www.sunistudio.com/cppfaq/) − C++ 常见问题
*   [Free Country](http://www.thefreecountry.com/sourcecode/cpp.shtml) − Free Country 提供了免费的 C++ 源代码和 C++ 库，这些源代码和库涵盖了压缩、存档、游戏编程、标准模板库和 GUI 编程等 C++ 编程领域。
*   [C and C++ Users Group](http://www.hal9k.com/cug/) − C 和 C++ 的用户团体提供了免费的涵盖各种编程领域 C++ 项目的源代码，包括 AI、动画、编译器、数据库、调试、加密、游戏、图形、GUI、语言工具、系统编程等。
c++语言官网 http://www.cplusplus.com/

C++ 有用的书籍
---------

*   [Essential C++ 中文版](https://s.click.taobao.com/t?e=m%3D2%26s%3DLi0UXGZauMYcQipKwQzePOeEDrYVVa64K7Vc7tFgwiHjf2vlNIV67mvQw%2F0oWRxq5ZnjZiNpIZZ0SY1KVGTulTasDm8dtc1PiCkt1wuc0S8%2Bah%2FIOB5zRCm8dRJ%2FXdaZlrfKbc84rldzLweBEW94KuMnnFiZU89RomfkDJRs%2BhU%3D&pvid=10_120.41.149.90_561_1523089225734)
*   [C++ Primer Plus 第6版中文版](https://s.click.taobao.com/t?e=m%3D2%26s%3D%2BDvqYICl6aocQipKwQzePOeEDrYVVa64K7Vc7tFgwiHjf2vlNIV67q6E28vpGaYdLzKPa%2Ff2nu90SY1KVGTulTasDm8dtc1PiCkt1wuc0S8%2Bah%2FIOB5zRCm8dRJ%2FXdaZlrfKbc84rle6JxiC6MKPJOzhr6zettVqxiXvDf8DaRs%3D&pvid=10_120.41.149.90_1177_1523091524310)
*   [C++ Primer中文版（第5版）](https://s.click.taobao.com/t?e=m%3D2%26s%3DfYVpIxJTkKEcQipKwQzePOeEDrYVVa64K7Vc7tFgwiHjf2vlNIV67kgvHK4EZ15Ylg6AtVBcXjx0SY1KVGTulTasDm8dtc1PiCkt1wuc0S8%2Bah%2FIOB5zRCm8dRJ%2FXdaZlrfKbc84rlecMDxhX1VqrwoUWrUV%2FQF3omfkDJRs%2BhU%3D&pvid=10_120.41.149.90_2020_1523090203718)


