title: 非常抱歉，由于资金紧张，ACM练习平台（acm.muyuanhuck.cn）关闭
date: '2019-05-16 11:00:41'
updated: '2019-06-20 17:40:57'
tags: [acm]
permalink: /acm.muyuanhuck.cn
---
# 给各位Acmer推荐几个新的练习平台
## 1.杭州电子科技大学的Acm练习平台
http://acm.hdu.edu.cn/listproblem.php?vol=1
## 2.北京大学Acm练习平台
http://poj.org/
## 3.同济大学
https://acm.tongji.edu.cn/problemset.php
## 4.浙江师范大学
http://acm.zjnu.edu.cn/CLanguage/problemlist
## 5.牛客网
https://www.nowcoder.com/ta/acm-training/
## 6.南阳理工大学
http://nyoj.top/problemset
## 7.浙江大学
http://acm.zju.edu.cn/onlinejudge/showProblemsets.do
## 8.西安电子科技大学
http://acm.xidian.edu.cn/
## 9.福州大学
http://acm.fzu.edu.cn/
## 10.中国科学技术大学
http://acm.ustc.edu.cn/ustcoj/problemlist.php
## 11.台州学院
http://www.tzcoder.cn/acmhome/problemList.do?method=show
## 12.复旦大学
http://icpc.fudan.edu.cn/problems/
## 13.武汉大学
http://acm.whu.edu.cn/olive/problems
## 14.万里ACM
http://wlacm.com/
## 15.山东理工大学
https://acm.sdut.edu.cn/onlinejudge2/index.php/Home/Index/problemlist
## 16.东北林业大学
http://acm.nefu.edu.cn/JudgeOnline/problem.php
## 17.两个国外的acm平台，需要科学上网
[https://icpcarchive.ecs.baylor.edu/index.php?option=com_onlinejudge&Itemid=8](https://icpcarchive.ecs.baylor.edu/index.php?option=com_onlinejudge&Itemid=8)
[https://uva.onlinejudge.org/index.php?option=com_onlinejudge&Itemid=8](https://uva.onlinejudge.org/index.php?option=com_onlinejudge&Itemid=8)


## 如有错误遗漏之处，欢迎大家在评论区补充指正。