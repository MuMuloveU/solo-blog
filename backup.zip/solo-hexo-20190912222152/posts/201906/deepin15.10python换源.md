title: deepin 15.10 python 换源
date: '2019-06-18 17:16:54'
updated: '2019-06-18 17:16:54'
tags: [linux, python]
permalink: /articles/2019/06/18/1560849414255.html
---
python官方源的服务器在国外，更新包的时候非常慢。
so,我们可以把源改成国内的镜像源
国内常用的镜像源有三个
```
// - 豆瓣：http://pypi.douban.com/simple/

// - 中科大：https://pypi.mirrors.ustc.edu.cn/simple/

// - 清华：https://pypi.tuna.tsinghua.edu.cn/simple
```
在Linux根目录创建 .pip/pip.ini (有就不用创建，没有就创建。)
写入以下内容（就把源改成了清华的镜像源）pip安装包就会快很多
```
[global]   
index-url = https://pypi.tuna.tsinghua.edu.cn/simple
```