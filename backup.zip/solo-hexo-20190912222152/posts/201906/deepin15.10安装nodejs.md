title: deepin 15.10 安装nodejs
date: '2019-06-19 11:33:16'
updated: '2019-06-19 11:33:16'
tags: [linux, npm, nodejs]
permalink: /articles/2019/06/19/1560915196420.html
---
# 安装~~~~
```
sudo apt-get install nodejs
sudo apt-get install node nodejs-bin
```
# 升级npm
```
sudo npm install npm -g
```

# 设置淘宝镜像源 

```
npm config set registry http://registry.npm.taobao.org
```
# 卸载
### 1.先卸载 npm 
```
  sudo npm uninstall npm -g
```
### 2.卸载nodejs
  ```
sudo apt-get remove nodejs
```