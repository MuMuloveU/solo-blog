title: deppin15.10 vs code 配置 C++ 开发环境
date: '2019-06-18 17:04:27'
updated: '2019-06-18 17:04:27'
tags: [linux, vscode, cpp]
permalink: /articles/2019/06/18/1560848667131.html
---
强烈建议大家在Linux环境下学习C++，window的gbk实在是把我弄得焦头烂额。。。

安装gcc g++ gdb
```
sudo apt-get gcc
sudo apt-get g++
sudo apt-get ggb
```

配置launch.json 这个文件在.vscode里面
```
{

// 使用 IntelliSense 了解相关属性。

// 悬停以查看现有属性的描述。

// 欲了解更多信息，请访问: https://go.microsoft.com/fwlink/?linkid=830387

"version": "0.2.0",

"configurations": [

  

{

"name": "(gdb) Launch", //配置名称，会在启动配置的下拉菜单中显示

"type": "cppdbg", //配置类型，只能为cppdbg

"request": "launch", //请求类型，可以为launch或attach

"program": "${workspaceFolder}/a.out", //将要调试的程序的路径

"args": [], //调试时传递给程序的命令行参数

"stopAtEntry": false, //设为true程序会暂停在入口处

"cwd": "${workspaceFolder}", //调试程序时的工作目录

"environment": [], //环境变量

"externalConsole": false, //调试时是否显示控制台窗口

"MIMode": "gdb", //指定连接的调试器，可以为gdb或lldb

"miDebuggerPath": "/usr/bin/gdb", //gdb路径

"setupCommands": [

{

"description": "Enable pretty-printing for gdb",

"text": "-enable-pretty-printing",

"ignoreFailures": true

}

],

"preLaunchTask": "build"  //调试开始前执行的任务，一般为编译程序

}

]

}
```

配置tasks.json 这个文件在.vscode里面
```
{

// See https://go.microsoft.com/fwlink/?LinkId=733558

// for the documentation about the tasks.json format

"version": "2.0.0",

"tasks": [

{

"label": "build",

"type": "shell",

"command": "g++",

"args": [

"${file}",

"-o",

"${workspaceRoot}/a.out"

],

"group": {

"kind": "build",

"isDefault": true

}

}

]

}
```
配置完这两个文件就可以F5调试不报错了
