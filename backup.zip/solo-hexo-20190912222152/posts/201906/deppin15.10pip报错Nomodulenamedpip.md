title: deppin15.10 pip 报错 No module named pip
date: '2019-06-18 16:56:55'
updated: '2019-06-18 16:56:55'
tags: [linux, python]
permalink: /articles/2019/06/18/1560848215436.html
---
分析 
Linux系统因为各种原因装了python但是没有安装pip
只需要装一下就行了，网上一堆瞎指挥的>_<
解决方案
python3
`sudo apt-get install python3-pip
`
python2
`sudo apt-get install python2-pip
`

