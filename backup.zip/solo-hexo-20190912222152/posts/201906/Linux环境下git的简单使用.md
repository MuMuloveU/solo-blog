title: Linux环境下git的简单使用
date: '2019-06-19 10:28:15'
updated: '2019-06-19 10:28:15'
tags: [linux, git]
permalink: /articles/2019/06/19/1560911295675.html
---
安装git
=====

```
sudo apt-get update  
sudo apt-get install git
```

用户信息配置(设置邮箱和名字)
===============

##### 第一个要配置的是你个人的用户名称和电子邮件地址。这两条配置很重要，每次 Git 提交时都会引用这两条信息，说明是谁提交了更新，所以会随更新内容一起被永久纳入历史记录：

```
git config --global user.name "Your Name"  
git config --global user.email "email@example.com"
```

##### 如果用了 --global 选项，那么更改的配置文件就是位于你用户主目录下的那个，以后你所有的仓库都会默认使用这里配置的用户信息。如果要在某个特定的仓库中使用其他名字或者电邮，只要去掉 --global 选项重新配置即可，新的设定保存在当前仓库的 .git/config 文件里。

文本编辑器配置
=======

##### 接下来要设置的是默认使用的文本编辑器。Git 需要你输入一些额外消息的时候，会自动调用一个外部文本编辑器给你用。默认会使用操作系统指定的默认编辑器，一般可能会是 Vi 或者 Vim。如果你有其他偏好，比如 Emacs 的话(我用的是deppin-editor)，可以重新设置：

`git config --global core.editor deepin-editor`

##### 差异分析工具:还有一个比较常用的是，在解决合并冲突时使用哪种差异分析工具。比如要改用 vimdiff 的话：

`git config --global merge.tool vimdiff`

###### Git 可以理解 kdiff3，tkdiff，meld，xxdiff，emerge，vimdiff，gvimdiff，ecmerge，和 opendiff 等合并工具的输出信息。当然，你也可以指定使用自己开发的工具。

查看配置信息
======

##### 要检查已有的配置信息，可以使用 git config --list 命令：

```
git config --list  
user.name=Scott Chacon  
user.email=schacon@gmail.com  
color.status=auto  
color.branch=auto  
color.interactive=auto  
color.diff=auto
```

##### 有时候会看到重复的变量名，那就说明它们来自不同的配置文件（比如 /etc/gitconfig 和 ~/.gitconfig),不过最终 Git 实际采用的是最后一个。

##### 也可以直接查阅某个环境变量的设定，只要把特定的名字跟在后面即可，像这样：

```
git config user.name  
Scott Chacon
```

获取Git帮助
=======

##### 想了解 Git 的各式工具该怎么用，可以阅读它们的使用帮助，方法有三：

```
git help <verb>  
git <verb> --help  
man git-<verb>
```

#### 比如，要学习 config 命令可以怎么用，运行：

`git help config`

生成公钥和私钥
=======

```
ssh-keygen -t rsa  
然后回车三下  
公钥在根目录的.ssh目录下 名字长的为公钥  
然后把公钥放到github/gitee上
```

Git的基本概念/常用命令及实例
================

### 什么是仓库

##### 在 Git 的概念中，仓库，就是你存在`.git`目录的那个文件夹内的所有文件，包括隐藏的文件，Git程序会再当前目录以及上级目录查找是否存在`.git`文件，如果存在，则会将`.git`目录存在的文件夹开始下的所有文件当成你需要管理的文件，所以，我们如果想将某个文件夹当做一个Git仓库，你可以在那个文件夹下通过终端(Window为Cmd或者PoewrShell或者Bash)来执行

`git init`

### 什么是版本

##### 严格来讲，Git并不存在版本的概念，但人们也硬是发展出了这么个玩意，在Git中，计数基础是提交，即我们常说的Commit，我们每做一点更改便可以产生一次提交，当提交累计起来，可以作为产品定型时，就在当前的Commit上打上一个标记，将这个标记我们称之为版本多少多少，那么就算完成了一个版本，标记本身被称之为Tag，请注意，在Git中，版本仅仅只是某一个提交的标签，并没有其他意义，Git本身也仅有打标签的功能，并没有版本功能，版本功能是根据Tag来扩展的，Git本身并没有

### 什么是分支

##### 这是Git中最重要的也是最常用的概念和功能之一，分支功能解决了正在开发的版本与上线版本稳定性冲突的问题在Git使用过程中，我们的默认分支一般是Master，当然，这是可以修改的，我们在Master完成一次开发，生成了一个稳定版本，那么当我们需要添加新功能或者做修改时，只需要新建一个分支，然后在该分支上开发，完成后合并到主分支即可

### 什么是提交

##### 提交在Git中同样是非常重要的概念，Git对于版本的管理其实是对于提交的管理，在整个Git仓库中，代码存在的形式并不是一分一分的代码，而是一个一个的提交，Git使用四十个字节长度的16进制字符串来标识每一个提交，这基本保证了每一个提交的标识是唯一的，然后通过组织一个按照时间排序的提交列表，就组成了我们所说的分支，请注意，分支在本质上只是一个索引，所以，我们可以任意回退，修正，即使因为某些原因丢失了，也可以重建另外，关于Git的储存方式:Git是仅仅只储存有修改的部分，并不会储存整个文件，所以，请不要删除文件夹整个文件夹的内容，除非你确定你不再需要他，否则请勿删除

### 什么是同步

##### 同步，也可以称之为拉取，在Git中是非常频繁的操作，和SVN不同，Git的所有仓库之间是平等的，所以，为了保证代码一致性，尽可能的在每次操作前进行一次同步操作，具体的为在工作目录下执行如下命令:

`git pull origin master`

##### 其中`origin`代表的是你远程的仓库，可以通过命令 `git remote -v` 查看，`master`是分支名，如果你本地是其他分支，请换成其他分支的名字，另，因为远程仓库与你本地仓库可能存在冲突，故当存在冲突时，请参考进阶篇的如何处理冲突

### 什么是推送

##### 和拉取一样，也是一个非常频繁的操作，当你代码有更新时，你需要更新到远程仓库，这个动作被称之为推送，执行的命令与拉取一样，只是将其中的`pull`这个单词改成`push`，同样，如果远程仓库存在你本地仓库没有的更新，则在推送前你需要先进行一次同步，如果你确定你不需要远程的更新，则在推送时加上 `-f` 选项，则可以强制推送，注:在协同开发中，我并不建议这么做，因为这样很可能覆盖别人的代码

##### 推送代码示例:

`git push origin master`

##### 强制推送代码示例:

`git push origin master -f`

### 什么是冲突

##### 在使用Git开发时，如果只是一个人使用，那么基本不会产生冲突，但是在多人合作开发的情况下，产生冲突是很正常的一件事情，关于如何处理冲突，请参考进阶篇的[如何处理代码冲突](https://gitee.com/help/articles/%24{domain}?v=%24{version}&t=83148) 这一小节

### 什么是合并

##### 合并这个命令通常情况下是用于两个分支的合并，一般用于本地分支，远程分支多用Pull命令，该命令的功能是将待合并分支与目标分支合并在一起，注意，这个命令只会合并当前版本之前的差异，两个分支的提交历史会根据提交时间重新组织索引，故只可能会产生一次冲突但是会生成一个提交，如果你不想生成这次提交，加上 `--base`参数即可

### 什么是暂存

##### 这个既是一个概念也是一个命令，其含义就是字面上的，作用就是可以将你当前正在进行的工作暂时存起来，然后在此基础上干别的事情，等你别的事情干完后，再转回来继续，注意，暂存只是针对你最后一次改动而言，即针对当前所在的版本的所有改动都算具体执行命令为:

##### 将当前改动暂存起来:

`git stash`

##### 恢复最后一次暂存的改动

`git stash pop`

##### 查看有多少暂存

`git stash list`

### 什么是撤销

##### 撤销命令使用是非常频繁的，因为某些原因，我们不再需要我们的改动或者新的改动有点问题，我们需要回退到某个版本，这时就需要用到撤销命令，或者说这个应该翻译成重置更加恰当。具体命令如下:

##### 撤销当前的修改:

`git reset --hard`

##### 请注意:以上命令会完全重置你的修改，如果你想保留某些文件，请使用checkout +文件路径 命令来逐一撤销修改

##### 如果你想重置到某一版本，可以将 `--hard` 改为具体的Commit的id如:

`git reset 1d7f5d89346`

Git 仓库基础操作
----------

[git命令](https://gitee.com/help/labels/79)

仓库基本管理
------

#### 初始化一个Git仓库(以`/home/gitee/test`文件夹为例)

```
$ cd /home/gitee/test    #进入git文件夹  
$ git init               #初始化一个Git仓库
```

#### 将文件添加到Git的暂存区

`$ git add "readme.txt" `

注：使用`git add -A`或`git add .` 可以提交当前仓库的所有改动。

#### 查看仓库当前文件提交状态（A：提交成功；AM：文件在添加到缓存之后又有改动）

`$ git status -s`

#### 从Git的暂存区提交版本到仓库，参数`-m`后为当次提交的备注信息

`$ git commit -m "1.0.0"`

#### 将本地的Git仓库信息推送上传到服务器

`$ git push https://gitee.com/***/test.git`

#### 查看git提交的日志

`$ git log`

远程仓库管理
------

#### 修改仓库名

一般来讲，默认情况下，在执行clone或者其他操作时，仓库名都是 origin 如果说我们想给他改改名字，比如我不喜欢origin这个名字，想改为 oschina 那么就要在仓库目录下执行命令:

`git remote rename origin oschina`

这样 你的远程仓库名字就改成了oschina，同样，以后推送时执行的命令就不再是 git push origin master 而是 git push oschina master 拉取也是一样的

#### 添加一个仓库

在不执行克隆操作时，如果想将一个远程仓库添加到本地的仓库中，可以执行

`git remote add origin  仓库地址`

注意: 1.origin是你的仓库的别名 可以随便改，但请务必不要与已有的仓库别名冲突 2. 仓库地址一般来讲支持 http/https/ssh/git协议，其他协议地址请勿添加

#### 查看当前仓库对应的远程仓库地址

`git remote -v`

这条命令能显示你当前仓库中已经添加了的仓库名和对应的仓库地址，通常来讲，会有两条一模一样的记录，分别是fetch和push，其中fetch是用来从远程同步 push是用来推送到远程

#### 修改仓库对应的远程仓库地址

`git remote set-url origin 仓库地址`

##### 请注意，这时你的修改仍然存在，只是你的最近一次提交的版本号变成了你要重置的版本，如果说你想完全丢弃修改，只需要加上 --hard参数就可以

##### 这里解释的只是一些工作中经常用到的git的基本概念，名词，并不包含Git的所有名词，概念解释，故本文未提到之处请自行使用搜索引擎搜索;另:文档编撰者尽可能的寻找标准的解释，因结果来自于互联网，如果解释有错漏之处，烦请指出并给出正确的解释，谢谢

##### 另，本文仅提到部分常使用的概念以及命令，但Git远远不止这些东西，所以，在本文找不到的内容请自行百度，这里推荐 Git的官方文档(中文和英文均有，由官方以及志愿者维护):[http://git-scm.com/book/zh/v2](http://git-scm.com/book/zh/v2) ，廖雪峰博客:[http://www.liaoxuefeng.com/wiki/0013739516305929606dd18361248578c67b8067c8c017b000](http://www.liaoxuefeng.com/wiki/0013739516305929606dd18361248578c67b8067c8c017b000)

Git Commit message 编写指南
-----------------------

介绍
--

在 Git 中，每次提交代码，都要写 Commit message（提交说明），否则就不允许提交。这个操作将通过 git commit 完成。

`git commit -m "hello world"`

> 上面代码的-m参数，就是用来指定 commit mesage 的。

如果一行不够，可以只执行git commit，就会跳出文本编译器，让你写多行。

`git commit`

格式
--

Commit message 包括三个部分：Header，Body 和 Footer。可以用下方的格式表示它的结构。

`<type>(<scope>): <subject>// 空一行<body>// 空一行<footer>`

> 其中，Header 是必需的，Body 和 Footer 可以省略(默认忽略)，一般我们在 `git commit` 提交时指定的 `-m` 参数，就相当于默认指定 Header。

> 不管是哪一个部分，任何一行都不得超过72个字符（或100个字符）。这是为了避免自动换行影响美观。

### Header

Header部分只有一行，包括三个字段：type（必需）、scope（可选）和subject（必需）。

#### type

*   **feat**：新功能（feature）
    
*   **fix**：修补bug
    
*   **docs**：文档（documentation）
    
*   **style**： 格式（不影响代码运行的变动）
    
*   **refactor**：重构（即不是新增功能，也不是修改bug的代码变动）
    
*   **test**：增加测试
    
*   **chore**：构建过程或辅助工具的变动
    

如果 type 为 feat 和 fix ，则该 commit 将肯定出现在 Change log 之中。其他情况（docs、chore、style、refactor、test）由你决定，要不要放入 Change log，建议是不要。

#### scope

scope用于说明 commit 影响的范围，比如数据层、控制层、视图层等等，视仓库不同而不同。

#### subject

subject是 commit 目的的简短描述，不超过50个字符。

*   以动词开头，使用第一人称现在时，比如change，而不是changed或changes
    
*   第一个字母小写
    
*   结尾不加句号（.）
    

### Body

Body 部分是对本次 commit 的详细描述，可以分成多行。下面是一个范例。

> More detailed explanatory text, if necessary. Wrap it to about 72 characters or so. Further paragraphs come after blank lines.- Bullet points are okay, too- Use a hanging indent

有两个注意点。

*   使用第一人称现在时，比如使用change而不是changed或changes。
    
*   应该说明代码变动的动机，以及与以前行为的对比。
    

### Footer

Footer 部分只用于两种情况。

#### 1、不兼容变动

如果当前代码与上一个版本不兼容，则 Footer 部分以BREAKING CHANGE开头，后面是对变动的描述、以及变动理由和迁移方法。

```
BREAKING CHANGE: isolate scope bindings definition has changed.  
​  
 To migrate the code follow the example below:  
​  
 Before:  
​  
 scope: {  
 myAttr: 'attribute',  
 }  
​  
 After:  
​  
 scope: {  
 myAttr: '@',  
 }  
​  
 The removed `inject` wasn't generaly useful for directives so there should be no code using it.
```

#### 2、关闭 Issue

如果当前 commit 针对某个issue，那么可以在 Footer 部分关闭这个 issue 。

> Closes #234

也可以一次关闭多个 issue 。

> Closes #123, #245, #992

### Revert

还有一种特殊情况，如果当前 commit 用于撤销以前的 commit，则必须以revert:开头，后面跟着被撤销 Commit 的 Header。

> revert: feat(pencil): add 'graphiteWidth' option
> 
> This reverts commit 667ecc1654a317a13331b17617d973392f415f02.

Body部分的格式是固定的，必须写成This reverts commit .，其中的hash是被撤销 commit 的 SHA 标识符。

如果当前 commit 与被撤销的 commit，在同一个发布（release）里面，那么它们都不会出现在 Change log 里面。如果两者在不同的发布，那么当前 commit，会出现在 Change log 的Reverts小标题下面。

一些简单的命令
=======

```
​  
git init  
git remote add origin git@github.com:michaelliao/learngit.git   
git clone git@gitee.com:NigelYao/BingWallpaper.git  
git add .  
git commit -m "shuoming"  
git push   /     git push -u origin master  
git pull 
```

未完待续...
=======

### 本文整理自[https://gitee.com/help/articles/4104](https://gitee.com/help/articles/4104)