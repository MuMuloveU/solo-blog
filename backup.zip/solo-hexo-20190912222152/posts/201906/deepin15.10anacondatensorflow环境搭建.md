title: deepin 15.10　anaconda　tensorflow 环境搭建
date: '2019-06-30 12:54:49'
updated: '2019-06-30 12:54:49'
tags: [python]
permalink: /articles/2019/06/30/1561870489204.html
---
#### 去这里下载镜像
https://mirrors.tuna.tsinghua.edu.cn/anaconda/archive/

#### 如何安装参考
https://blog.csdn.net/kerry_55/article/details/93511309
https://blog.csdn.net/lk7688535/article/details/93637076

#### 设置国内镜像源
```
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/free/
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/main/
conda config --set show_channel_urls yes
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/conda-forge/
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/msys2/ 
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/bioconda/
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/menpo/
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/pytorch/
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/peterjc123/

```

#### 设置pip源，更新pip
```
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple pip -U
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple
```

#### 安装tensorflow
```
pip install tensorflow
```
ERROR: tensorflow 1.13.1 has requirement tensorboard<1.14.0,>=1.13.0, but you’ll have tensorboard 1.11.0 which is incompatible.
解决方法
```
pip install tensorflow-tensorboard
pip install tensorflow
```

#### 关于anaconda的详细使用，请参考。
https://www.baidu.com/baidu?wd=anaconda%E4%BD%BF%E7%94%A8%E6%95%99%E7%A8%8B