title: 解决Deepin系统上OBS闪退的问题
date: '2019-07-14 16:02:56'
updated: '2019-07-14 16:13:17'
tags: [deepin, obs]
permalink: /articles/2019/07/14/1563091376495.html
---
### 安装Flatpak
`apt install flatpak`
` apt install gnome-software-plugin-flatpak`
`flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo`

### 通过Flatpak安装obs
`flatpak install flathub com.obsproject.Studio`

### 运行obs
`flatpak run com.obsproject.Studio`

### 参考
https://flatpak.org/setup/Debian/
https://flathub.org/apps/details/com.obsproject.Studio

### 完美！

### 新建一个obs.sh文件
```
#!/bin/bash
flatpak run com.obsproject.Studio

```
###### 右键-->属性-->权限管理-->勾上允许以程序运行 
###### 这样启动obs的时候双击这个文件，选择运行，大功告成！