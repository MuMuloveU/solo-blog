title: Github上一些国内顶级大学学习资料的分享,欢迎补充
date: '2019-04-14 15:49:25'
updated: '2019-04-14 15:49:25'
tags: [资源分享]
permalink: /articles/2019/04/14/1555228165766.html
---
![](https://img.hacpai.com/bing/20180214.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

*   [北京大学的课程资料](https://github.com/lib-pku/libpku)
*   [浙江大学课程攻略共享计划](https://github.com/QSCTech/zju-icicles)
*   [气垫船计划——免费、去中心化的北京大学往年题资料库](https://github.com/martinwu42/project-hover)
*   [北京大学信科学生会学术部资料库](https://github.com/EECS-PKU-XSB/Shared-learning-materials)
*   [北大计算机课程大作业](https://github.com/tongtzeho/PKUCourse)
*   [清华大学计算机系课程攻略](https://github.com/PKUanonym/REKCARC-TSC-UHT)
*   [东南大学课程共享计划](https://github.com/zjdx1998/seucourseshare)
*   [中国科学技术大学计算机学院课程资源](https://github.com/USTC-Resource/USTC-Course)
*   [上海交通大学课程资料分享](https://github.com/CoolPhilChen/SJTU-Courses/)
*   [中山大学课程资料分享](https://github.com/sysuexam/SYSU-Exam)
