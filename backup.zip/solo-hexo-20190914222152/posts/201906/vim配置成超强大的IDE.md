title: vim 配置成超强大的IDE
date: '2019-06-18 19:25:15'
updated: '2019-06-18 19:25:15'
tags: [linux, vim]
permalink: /articles/2019/06/18/1560857115774.html
---
# 只需要一条命令
```
 wget -qO- https://raw.github.com/ma6174/vim/master/setup.sh | sh -x

```